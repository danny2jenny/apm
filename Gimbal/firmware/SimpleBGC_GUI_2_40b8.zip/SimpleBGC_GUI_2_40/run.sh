javaw -Djava.library.path=./lib -jar SimpleBGC_GUI.jar
